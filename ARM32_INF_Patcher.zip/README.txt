ARM32 INF Patcher Tool

How to use:
1. Make sure Python is installed and added to PATH.
2. Double-click 'run_patcher.cmd' to run the script.
3. It will patch 'example.inf' and create 'example_patched.inf'.

You can replace 'example.inf' with any other INF file to test it.
